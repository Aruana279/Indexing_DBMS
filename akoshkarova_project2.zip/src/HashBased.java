import java.util.HashMap;
public class HashBased {
    private HashMap<Integer, String> hashMap;


    // Read all files in the dataset directory, one by one, and for each file, read record by record.
    public void read(int randomV){
        // If hashmap does not contain key, say so
        if(hashMap.containsKey(randomV)==false) {
            System.out.println("No records found for randomV of " + randomV + "\nNo I/Os performed");
        }
        else {
            Reader.printRecord(hashMap.get(randomV));
        }
    }

    public void add(int randomV, String frID){
        // check if exists already
        if(hashMap.containsKey(randomV)){
            // split into index and record
            if(hashMap.get(randomV).contains(frID.substring(0, 3))){
                String record = hashMap.get(randomV);
                int index = record.indexOf(frID.substring(0, 3));
                record = record.substring(0, index + 3) + frID.substring(3) + "," + record.substring(index + 3);
                // update hashmap
                hashMap.replace(randomV, record);
            } else {
                hashMap.replace(randomV, hashMap.get(randomV) + ";" + frID);
            }
        } else {
            hashMap.put(randomV, frID);
        }
    }
}
