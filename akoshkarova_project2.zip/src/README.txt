Aruzhan Koshkarova akoshkarova 880066652
Section I.

1. open terminal in the project directory. Check for dataset folder to be in the directory
2. navigate to folder
3. to run : java main
4. possible commands:
    - createindexonproject2dataset[RANDV]
    - select*fromproject2datasetwhererandomv=[VALUE]
    - select*fromproject2datasetwhererandomv>[VALUE1]andrandomv<[VALUE2]
    - select*fromproject2datasetwhererandomv!=[VALUE]
    - exit

Section II
All of my code seems to be working

Section III
Instead of using many for loops, used an iterable