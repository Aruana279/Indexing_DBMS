public class ArrayBased {
    public String[] myArray;

    public void rangeSearch(int start, int end){
        // check for valid range
        if(start < 0 || end < 0 || start > 5000){
            System.out.println("Invalid range search");
        }

        // set end to 5000 if too high
        if (end > 5000){
            System.out.println("Less than is too big");
            end = 5000;
        }
        String record = "";
        for(int i = start; i < end - 1; i++){
            if(myArray[i] != null){
                String[] allFiles = myArray[i].split(";");

                // Loop over all files
                for(String s : allFiles){
                    // check if file is in record
                    if(record.contains(s.substring(0, 3))){
                        // add file index to record
                        int fileIndex = record.indexOf(s.substring(0, 3));
                        record = record.substring(0, fileIndex + 3) + s.substring(3) + "," + record.substring
                                (fileIndex + 3);
                    } else record = record + ";" + s;
                }
            }
        }

        // check if records empty
        if(record.length() < 1) {
            System.out.println("No records found");
        }
        // else print
        else {
            record = record.substring(1);
            Reader.printRecord(record);
        }
    }



    public void add(int randV, String frID){
        // subtract 1, because starts with 1
        randV = randV-1;
        // if entry doesn't exist
        if(myArray[randV] == null) {
            myArray[randV] = frID;
        }
        else {
            if(myArray[randV].contains(frID.substring(0, 3))){
                int index = myArray[randV].indexOf(frID.substring(0, 3));
                myArray[randV] = myArray[randV].substring(0, index + 3) + frID.substring(3) + ", " + myArray[randV].substring(index + 3);
            } else myArray[randV] = myArray[randV] + ";" + frID;
        }
    }
}
