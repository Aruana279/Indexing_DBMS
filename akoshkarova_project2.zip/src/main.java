import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;


public class main {

    public static void main(String[] args) throws IOException{
        Database db = new Database();
        System.out.println("Program is ready and waiting for user command");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        boolean running = true;

        while (running) {
            String line = reader.readLine().toLowerCase();
            line = reader.readLine().toLowerCase().replace(" ", "");

            //changed everything to lowercase for easier split
            if(line.contains("createindexonproject2dataset")) {
                db.createIndexes();
            }
            else if(line.contains("select*fromproject2datasetwhererandomv=")) {
                db.querySearch(0, Integer.parseInt(line.replace("select*fromproject2datasetwhererandomv=", "")), 0);
            }
            else if(line.contains("select*fromproject2datasetwhererandomv>") && line.contains("andrandomv<")) {
                line = line.replace("select*fromproject2datasetwhererandomv>", "");
                String[] range = line.split("andrandomv<");
                db.querySearch(1, Integer.parseInt(range[0]), Integer.parseInt(range[1]));
            }
            else if(line.contains("select*fromproject2datasetwhererandomv!=")) {
                db.querySearch(2, Integer.parseInt(line.replace("select*fromproject2datasetwhererandomv!=", "")), 0);
            }
            else if(line.contains("exit")){
                running=false;
                break;
            }
        }
    }
}

