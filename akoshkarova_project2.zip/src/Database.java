import java.util.Iterator;

// Implement string iterable so we can use "this" as a string type
public class Database implements Iterable<String> {

    private HashBased hashBased;
    private ArrayBased arrayBased;



    // build both indexes and keep them in memory
    public void createIndexes(){
        hashBased = new HashBased();
        arrayBased = new ArrayBased();


        // Loop over records
        for(String r : this){
            int randomV = Integer.parseInt(r.substring(33, 37));
            String frID = r.substring(1, 3) + ":" + r.substring(7, 10);

            // Add randomv and fileandrecordID elements to both indexes
            hashBased.add(randomV, frID);
            arrayBased.add(randomV, frID);
        }
        System.out.println("The hash-based and array-based indexes are built successfully.\nProgram is ready and waiting for user command");
    }

    public void querySearch(int searchType, int randV1, int randV2){
        // If no indexes, use table scans
        if(hashBased == null){
            searchType += 3;
        }
        long startTime = System.currentTimeMillis();

        // Analyze search type and use corresponding search method
        switch(searchType) {
            case 0: // equality search
                equality(randV1);
                break;
            case 1: // range search
                range(randV1, randV2);
                break;
            case 2: // inequality table scan
                inequalityBasedSearch(randV1);
                break;
            case 3: // full (equality) table scan
                fullEqualityTableScan(randV1);
                break;
            case 4: // range table scan
                rangeTableScan(randV1, randV2);
                break;
            case 5: // inequality table scan
                inequalityBasedSearch(randV1);
                break;

        }

        // prints total time
        long totalTime = System.currentTimeMillis() - startTime;
        System.out.println("Search time: " + totalTime + "ms");
    }

    // used the hash-based indexing
    public void equality(int randomV){
        hashBased.read(randomV);
    }
    // used the array-based indexing
    public void range(int start, int end){
        arrayBased.rangeSearch(start, end);
    }
    // the database system needs to read the entire table (all its blocks) one by
    //one.
    public void fullEqualityTableScan(int randomV){
        for(String r : this){
            //the records are scanned one by one and checked against the query predicate.
            if(Integer.parseInt(r.substring(33, 37)) == randomV){
                System.out.println(r);
            }
        }
        System.out.println("Full table scan is complete");
    }

    public void rangeTableScan(int start, int end){
        for(String r : this){
            if(Integer.parseInt(r.substring(33, 37)) > start &&
                    Integer.parseInt(r.substring(33, 37)) < end) System.out.println(r);
        }

        System.out.println("no index available");
    }
    public void inequalityBasedSearch(int randV){
        for(String r : this){
            if(Integer.parseInt(r.substring(33, 37)) != randV){
                System.out.println(r);
            }
        }
        System.out.println("inequality table scan complete");
    }

    @Override
    public Iterator<String> iterator(){
        return new Reader();
    }
}
